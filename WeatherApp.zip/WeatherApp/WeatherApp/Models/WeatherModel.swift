//
//  WeatherModel.swift
//  WeatherApp
//
//  Created by Apple on 12/9/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

class WeatherModel: NSObject{
    var id: Int
    var weather_state_name: String
    var weather_state_abbr: String
    var wind_direction_compass: String
    var created: String
    var applicable_date: String
    var min_temp: Double
    var max_temp: Double
    var the_temp: Double
    var wind_speed: Double
    var wind_direction: Double
    var air_pressure: Double
    var humidity: Double
    var visibility: Double
    var predictability: Double
    
    init(id: Int,weather_state_name: String,weather_state_abbr: String,wind_direction_compass: String,created: String,applicable_date: String,min_temp: Double,max_temp: Double,the_temp: Double,wind_speed: Double,wind_direction: Double,air_pressure: Double,humidity: Double,visibility: Double,predictability: Double) {
        self.id = id
        self.weather_state_name = weather_state_name
        self.weather_state_abbr = weather_state_abbr
        self.wind_direction_compass = wind_direction_compass
        self.created = created
        self.applicable_date = applicable_date
        self.min_temp = min_temp
        self.max_temp = max_temp
        self.the_temp = the_temp
        self.wind_speed = wind_speed
        self.wind_direction = wind_direction
        self.air_pressure = air_pressure
        self.humidity = humidity
        self.visibility = visibility
        self.predictability = predictability
    }
    
}
