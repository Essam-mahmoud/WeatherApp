//
//  DayWeatherDetailsViewController.swift
//  WeatherApp
//
//  Created by Apple on 12/10/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import SwiftyJSON

class DayWeatherDetailsViewController: UIViewController {
    
    @IBOutlet weak var weatherDetailsTableView: UITableView!
    var weatherObj: WeatherModel?
    var woeid: Int?
    var DayDetails = [WeatherModel]()
    var http = HttpHelper()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        weatherDetailsTableView.delegate = self
        weatherDetailsTableView.dataSource = self
        weatherDetailsTableView.tableFooterView = UIView()
        http.delegate = self
        title = weatherObj?.applicable_date
        getDayDetails()
    }
    
    //function to get data from end point
    func getDayDetails(){
        
        let date = weatherObj!.applicable_date.split {$0 == "-"}.map(String.init)
        let serviceUrl = ApiConstant.getDayDetails + "\(woeid!)/" + date[0] + "/" + date[1] + "/" + date[2]
        
        AppCommon.sharedInstance.ShowLoader(self.view,color: UIColor.hexColorWithAlpha(string: "#000000", alpha: 0.2))
        http.GetWithoutHeader(url: serviceUrl, parameters: [:], Tag: 1)
    }
}


//MARK:- extension of the http helper delegate
extension DayWeatherDetailsViewController: HttpHelperDelegate{
    func receivedResponse(dictResponse: Any, Tag: Int) {
        print(dictResponse)
        AppCommon.sharedInstance.dismissLoader(self.view)
        let json = JSON(dictResponse).arrayValue
        print(json)
        
        if Tag == 1{
            for item in json{
                let WeatherObject = WeatherModel(id: item["id"].intValue, weather_state_name: item["weather_state_name"].stringValue, weather_state_abbr: item["weather_state_abbr"].stringValue, wind_direction_compass: item["wind_direction_compass"].stringValue, created: item["created"].stringValue, applicable_date: item["applicable_date"].stringValue, min_temp: item["min_temp"].doubleValue, max_temp: item["max_temp"].doubleValue, the_temp: item["the_temp"].doubleValue, wind_speed: item["wind_speed"].doubleValue, wind_direction: item["wind_direction"].doubleValue, air_pressure: item["air_pressure"].doubleValue, humidity: item["humidity"].doubleValue, visibility: item["visibility"].doubleValue, predictability: item["predictability"].doubleValue)
                DayDetails.append(WeatherObject)
            }
            weatherDetailsTableView.reloadData()
        }
    }
    
    func receivedErrorWithStatusCode(statusCode: Int) {
        AppCommon.sharedInstance.alert(title: "Error", message: "Please check your internet connection", controller: self, actionTitle: "Ok", actionStyle: .default)
        AppCommon.sharedInstance.dismissLoader(self.view)
    }
    
    func retryResponse(numberOfrequest: Int) {
        
    }
    
    
}

//MARK:- extension of Table view delegate
extension DayWeatherDetailsViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DayDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = weatherDetailsTableView.dequeueReusableCell(withIdentifier: "WeatherDetailsCell", for: indexPath) as! WeatherDetailsCell
        cell.setupCell(weatherDetails: DayDetails[indexPath.row])
        return cell
    }
}
