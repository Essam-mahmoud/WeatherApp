//
//  WeatherCell.swift
//  WeatherApp
//
//  Created by Apple on 12/9/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import Kingfisher

class WeatherCell: UITableViewCell {
    
    
    @IBOutlet weak var dayNameLBL: UILabel!
    @IBOutlet weak var temprtureLBL: UILabel!
    @IBOutlet weak var weaterStateLBL: UILabel!
    @IBOutlet weak var cityLBL: UILabel!
    @IBOutlet weak var weatherImage: UIImageView!
    @IBOutlet weak var dayLBL: UILabel!
    @IBOutlet weak var humidityLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setupCell(weatherObject: WeatherModel, city: String){
        
        // set the UI elements
        humidityLBL.text = "\(weatherObject.humidity)%"
        weaterStateLBL.text = weatherObject.weather_state_name
        cityLBL.text = city
        
        //set the temprture
        let roundedMaxTemp = Double(round(10*weatherObject.max_temp)/10)
        let roundedMinTemp = Double(round(10*weatherObject.min_temp)/10)
        temprtureLBL.text = "\(roundedMaxTemp)°/\(roundedMinTemp)°"
        
        //set the day number
        var day = weatherObject.applicable_date.split {$0 == "-"}.map(String.init)
        dayLBL.text = day[2]
        
        //set the weather image
        weatherImage.kf.setImage(with: AppCommon.sharedInstance.setWeatherImage(name: weatherObject.weather_state_abbr))
        
        //get the name of the day
        if let weekday = AppCommon.sharedInstance.getDayOfWeek(weatherObject.applicable_date){
            dayNameLBL.text = AppCommon.sharedInstance.getDayName(id: weekday)
        }  
    }
}
