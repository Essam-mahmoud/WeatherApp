//
//  ViewController.swift
//  WeatherApp
//
//  Created by Apple on 12/9/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import DropDown
import SwiftyJSON

class WeatherViewController: UIViewController {
    
    @IBOutlet weak var chooseButton: UIButton!
    @IBOutlet weak var countryNameLBL: UILabel!
    @IBOutlet weak var weatherTableView: UITableView!
    let dropdown = DropDown()
    let http = HttpHelper()
    var LocationDetails = [WeatherModel]()
    var selectedCountry = "Sofia"
    
    let countries = ["Sofia": 839722, "New Yourk": 2459115, "Tokyo": 1118370] as [String: Any]
    var currentCountries = [String:Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        http.delegate = self
        title = "Weather"
        weatherTableView.dataSource = self
        weatherTableView.delegate = self
        getDataFromService()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let stordCountries = UserDefaults.standard.dictionary(forKey: "myData")
        if stordCountries != nil {
            currentCountries = stordCountries!
        }else{
            UserDefaults.standard.set(countries, forKey: "myData")
            currentCountries = countries
        }
    }
    
    // function to get data from end point
    func getDataFromService(){
        let serviceURL = ApiConstant.getLocationDetails + "44418"
        AppCommon.sharedInstance.ShowLoader(self.view,color: UIColor.hexColorWithAlpha(string: "#000000", alpha: 0.2))
        http.GetWithoutHeader(url: serviceURL, parameters: [:], Tag: 1)
    }
    
    //drop down list function
    @IBAction func DropDownPressed(_ sender: UIButton) {
        let countryArray = Array(currentCountries.keys)
        dropdown.hide()
        dropdown.direction = .bottom
        dropdown.width = 300
        DropDown.startListeningToKeyboard()
        dropdown.anchorView = chooseButton
        dropdown.dataSource = countryArray
        dropdown.selectionAction = { index,string in
            self.LocationDetails.removeAll()
            self.countryNameLBL.text = string
            self.selectedCountry = string
            let countryWeoid = self.currentCountries[string]
            let serviceURL = ApiConstant.getLocationDetails + "\(countryWeoid!)"
            AppCommon.sharedInstance.ShowLoader(self.view,color: UIColor.hexColorWithAlpha(string: "#000000", alpha: 0.2))
            self.http.GetWithoutHeader(url: serviceURL, parameters: [:], Tag: 1)
        }
        dropdown.show()
        
    }
    
    @IBAction func addLocationPressed(_ sender: Any) {
        let addViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddLocationViewController") as! AddLocationViewController
        self.navigationController?.pushViewController(addViewController, animated: true)
    }
    
}

//MARK:- extension of Table view delegate
extension WeatherViewController: UITableViewDataSource, UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return LocationDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = weatherTableView.dequeueReusableCell(withIdentifier: "WeatherCell", for: indexPath) as! WeatherCell
        cell.setupCell(weatherObject: LocationDetails[indexPath.row], city: selectedCountry)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        weatherTableView.deselectRow(at: indexPath, animated: true)
        let detailsViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DayWeatherDetailsViewController") as! DayWeatherDetailsViewController
        detailsViewController.weatherObj = LocationDetails[indexPath.row]
        detailsViewController.woeid = (countries[selectedCountry] as! Int)
        self.navigationController?.pushViewController(detailsViewController, animated: true)
    }
    
    
}

//MARK:- extension of the http helper delegate
extension WeatherViewController: HttpHelperDelegate{
    func receivedResponse(dictResponse: Any, Tag: Int) {
        print(dictResponse)
        AppCommon.sharedInstance.dismissLoader(self.view)
        let json = JSON(dictResponse)
        print(json)
        
        if Tag == 1{
            let data = JSON(json["consolidated_weather"]).arrayValue
            print(data)
            for item in data{
                let WeatherObject = WeatherModel(id: item["id"].intValue, weather_state_name: item["weather_state_name"].stringValue, weather_state_abbr: item["weather_state_abbr"].stringValue, wind_direction_compass: item["wind_direction_compass"].stringValue, created: item["created"].stringValue, applicable_date: item["applicable_date"].stringValue, min_temp: item["min_temp"].doubleValue, max_temp: item["max_temp"].doubleValue, the_temp: item["the_temp"].doubleValue, wind_speed: item["wind_speed"].doubleValue, wind_direction: item["wind_direction"].doubleValue, air_pressure: item["air_pressure"].doubleValue, humidity: item["humidity"].doubleValue, visibility: item["visibility"].doubleValue, predictability: item["predictability"].doubleValue)
                LocationDetails.append(WeatherObject)
            }
            weatherTableView.reloadData()
            
        }
    }
    
    func receivedErrorWithStatusCode(statusCode: Int) {
        AppCommon.sharedInstance.alert(title: "Error", message: "Please check your internet connection", controller: self, actionTitle: "Ok", actionStyle: .default)
        AppCommon.sharedInstance.dismissLoader(self.view)
    }
    
    func retryResponse(numberOfrequest: Int) {
        
    }
    
    
}
