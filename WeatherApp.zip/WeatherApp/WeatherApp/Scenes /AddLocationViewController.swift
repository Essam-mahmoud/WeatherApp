//
//  AddLocationViewController.swift
//  WeatherApp
//
//  Created by Apple on 12/10/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import SwiftyJSON

class AddLocationViewController: UIViewController {

    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var searchTF: UITextField!
    @IBOutlet weak var resultLBL: UILabel!
    var foundedCity: CountryModel?
    
    var http = HttpHelper()
    override func viewDidLoad() {
        super.viewDidLoad()
        http.delegate = self
        title = "Add City"
        resultLBL.isHidden = true
        addButton.isHidden = true

        // Do any additional setup after loading the view.
    }
    
    @IBAction func searchBTNPressed(_ sender: UIButton) {
        getLocationWOEID()
    }
    
    @IBAction func addCityBTNPressed(_ sender: UIButton) {
        guard var currentCountries = UserDefaults.standard.dictionary(forKey: "myData") as? [String: Int] else {return}
        currentCountries[foundedCity!.title] = foundedCity!.woeid
        UserDefaults.standard.set(currentCountries, forKey: "myData")
        let alert = UIAlertController(title: "Success", message: "City Successfully Added", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default) { (UIAlertAction) in
            self.navigationController?.popViewController(animated: true)
        }
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    //function to get the location data from end point 
    func getLocationWOEID(){
        guard let cityName = searchTF.text else {return}
        let serverUrl = ApiConstant.getLocation + cityName
        AppCommon.sharedInstance.ShowLoader(self.view,color: UIColor.hexColorWithAlpha(string: "#000000", alpha: 0.2))
        http.GetWithoutHeader(url: serverUrl, parameters: [:], Tag: 1)
    }
    // function to setup the view
    func setupView(country: CountryModel){
        if country.title != ""{
            resultLBL.isHidden = false
            resultLBL.text = country.title
            addButton.isHidden = false
        }else{
            resultLBL.isHidden = false
            resultLBL.text = "No result found to this search please try another city"
            addButton.isHidden = true
        }
    }
    
}

//MARK:- extension of the http helper delegate
extension AddLocationViewController: HttpHelperDelegate{
    func receivedResponse(dictResponse: Any, Tag: Int) {
        AppCommon.sharedInstance.dismissLoader(self.view)
        let json = JSON(dictResponse).arrayValue
        if Tag == 1{
            for item in json{
                let cityObject = CountryModel(title: item["title"].stringValue, location_type: item["location_type"].stringValue, woeid: item["woeid"].intValue, latt_long: item["latt_long"].stringValue)
                foundedCity = cityObject
            }
            setupView(country: foundedCity ?? CountryModel(title: "", location_type: "", woeid: 0, latt_long: ""))
        }
    }
    
    func receivedErrorWithStatusCode(statusCode: Int) {
        AppCommon.sharedInstance.alert(title: "Error", message: "Please check your internet connection", controller: self, actionTitle: "Ok", actionStyle: .default)
        AppCommon.sharedInstance.dismissLoader(self.view)
    }
    
    func retryResponse(numberOfrequest: Int) {
        
    }
    
    
}
