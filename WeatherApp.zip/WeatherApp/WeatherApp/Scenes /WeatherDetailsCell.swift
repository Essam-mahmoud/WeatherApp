//
//  WeatherDetailsCell.swift
//  WeatherApp
//
//  Created by Apple on 12/10/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import Kingfisher

class WeatherDetailsCell: UITableViewCell {
    
    @IBOutlet weak var timeLBL: UILabel!
    @IBOutlet weak var weatherStateImage: UIImageView!
    @IBOutlet weak var tempLBL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setupCell(weatherDetails: WeatherModel){
        weatherStateImage.kf.setImage(with: AppCommon.sharedInstance.setWeatherImage(name: weatherDetails.weather_state_abbr))
        
        let roundedTemp = Double(round(10*weatherDetails.the_temp)/10)
        tempLBL.text = "\(roundedTemp)°"
        
        //translate the time from date to time am/pm
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'hh:mm:ss.SSSSSSZ"
        guard let date = dateFormatter.date(from: weatherDetails.created) else {return}
        let outputDateFormatter = DateFormatter()
        outputDateFormatter.dateFormat = "h:mm a"
        let outputString = outputDateFormatter.string(from: date)
        timeLBL.text = outputString
    }
    
}
