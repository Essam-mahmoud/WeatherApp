//
//  ApiConstant.swift
//  WeatherApp
//
//  Created by Apple on 12/9/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

open class ApiConstant{
    static let baseUrl = "https://www.metaweather.com"
    static let SERVER_URL = baseUrl + "/api"
    static let getLocation = SERVER_URL + "/location/search/?query="
    static let getLocationDetails = SERVER_URL + "/location/"
    static let getDayDetails = SERVER_URL + "/location/"
}
