//
//  Support.swift
//  WeatherApp
//
//  Created by Apple on 12/9/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

enum statusCode {
    static let NOT_FOUND = 404
    static let OK = 200
    static let BAD_GATEWAY = 502
    static let SERVICE_UNAVAILABLE = 503
    static let NO_CONTENT = 204
    static let ACCEPTED = 0
    static let CREATED = 0
}

enum weaterIcon {
    static let SNOW = "/static/img/weather/png/64/sn.png"
    static let SLEET = "/static/img/weather/png/64/sl.png"
    static let HAIL = "/static/img/weather/png/64/h.png"
    static let THUNDER_STORM = "/static/img/weather/png/64/t.png"
    static let HEAVY_RAIN = "/static/img/weather/png/64/hr.png"
    static let LIGHT_RAIN = "/static/img/weather/png/64/lr.png"
    static let SHOWERS = "/static/img/weather/png/64/s.png"
    static let HEAVY_CLOUD = "/static/img/weather/png/64/hc.png"
    static let LIGHT_CLOUD = "/static/img/weather/png/64/lc.png"
    static let CLEAR = "/static/img/weather/png/64/c.png"
}


