//
//  AppCommon.swift
//  AshakAlena
//
//  Created by Mohammad Farhan on 22/12/176/8/17.
//  Copyright © 2017 Mohammad Farhan. All rights reserved.
//

import Foundation
import UIKit
//import JBWebViewController
import SwiftyJSON

class AppCommon: UIViewController {
    
    static let sharedInstance = AppCommon()
    
    func dismissLoader(_ view:UIView){
        view.viewWithTag(1000)?.removeFromSuperview()
    }

    func ShowLoader(_ view:UIView,color:UIColor){
        let Loader  = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
        Loader.backgroundColor = color
        Loader.tag = 1000
        let loadingIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
        loadingIndicator.center = Loader.center
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.whiteLarge
        loadingIndicator.color = UIColor.black
        loadingIndicator.startAnimating();
        Loader.addSubview(loadingIndicator)
        view.addSubview(Loader)
    }
    
    func alert(title: String, message: String, controller: UIViewController, actionTitle: String, actionStyle: UIAlertAction.Style) {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: actionTitle, style: actionStyle, handler: nil))
        alert.view.tintColor = UIColor.hexColor(string: "023f82")
        
        controller.present(alert, animated: true, completion: nil)
        
    }
    
    // function to set the image of the weather state
    func setWeatherImage(name: String) -> URL{
        var imageUrl:URL!
        switch name {
        case "sn":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.SNOW)
            //weatherImage.kf.setImage(with: imageUrl)
        case "sl":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.SLEET)
            //weatherImage.kf.setImage(with: imageUrl)
        case "h":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.HAIL)
            //weatherImage.kf.setImage(with: imageUrl)
        case "t":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.THUNDER_STORM)
            //weatherImage.kf.setImage(with: imageUrl)
        case "hr":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.HEAVY_RAIN)
            //weatherImage.kf.setImage(with: imageUrl)
        case "lr":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.LIGHT_RAIN)
            //weatherImage.kf.setImage(with: imageUrl)
        case "s":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.SHOWERS)
            //weatherImage.kf.setImage(with: imageUrl)
        case "hc":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.HEAVY_CLOUD)
            //weatherImage.kf.setImage(with: imageUrl)
        case "lc":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.LIGHT_CLOUD)
            //weatherImage.kf.setImage(with: imageUrl)
        case "c":
             imageUrl = URL(string: ApiConstant.baseUrl + weaterIcon.CLEAR)
            //weatherImage.kf.setImage(with: imageUrl)
        default:
            break
        }
        return imageUrl
    }
    
    // function to get the day number
    func getDayOfWeek(_ today:String) -> Int? {
        let formatter  = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        guard let todayDate = formatter.date(from: today) else { return nil }
        let myCalendar = Calendar(identifier: .gregorian)
        let weekDay = myCalendar.component(.weekday, from: todayDate)
        return weekDay
    }
    
    // function to get the day name from day number
    func getDayName(id: Int) -> String{
        var returnDay = ""
        switch id {
        case 1:
            returnDay = "SUN"
        case 2:
            returnDay = "MON"
        case 3:
            returnDay = "TUE"
        case 4:
            returnDay = "WED"
        case 5:
            returnDay = "THU"
        case 6:
            returnDay = "FRI"
        case 7:
            returnDay = "SAT"
        default:
            break
        }
        return returnDay
    }

}
